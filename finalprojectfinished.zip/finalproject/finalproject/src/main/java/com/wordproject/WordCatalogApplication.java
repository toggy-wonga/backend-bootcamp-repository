package com.wordproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WordCatalogApplication {

    public static void main(String[] args) {
        SpringApplication.run(WordCatalogApplication.class, args);
    }
}
