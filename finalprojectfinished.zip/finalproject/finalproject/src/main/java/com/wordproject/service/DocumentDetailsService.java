package com.wordproject.service;
import org.springframework.transaction.annotation.Transactional;

import com.wordproject.entity.DocumentDetails;
import com.wordproject.entity.ProjectDetails;
import com.wordproject.errorhandling.ResourceNotFoundException;
import com.wordproject.repository.DocumentDetailsRepository;
import com.wordproject.repository.ProjectDetailsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

/**
 * Service for DocumentDetails — all 4 CRUD operations.
 */
@Transactional
@Service
public class DocumentDetailsService {

    private final DocumentDetailsRepository documentRepo;
    private final ProjectDetailsRepository projectRepo;

    @Autowired
    public DocumentDetailsService(DocumentDetailsRepository documentRepo,
                                   ProjectDetailsRepository projectRepo) {
        this.documentRepo = documentRepo;
        this.projectRepo = projectRepo;
    }

    // CREATE
    public DocumentDetails createDocument(Integer projectId, DocumentDetails document) {
        ProjectDetails project = projectRepo.findById(projectId)
            .orElseThrow(() -> new ResourceNotFoundException("Project not found with id: " + projectId));
        document.setDocumentId(null);
        document.setProject(project);
        return documentRepo.save(document);
    }

    // READ ALL
    public List<DocumentDetails> getAllDocuments() {
        return documentRepo.findAll();
    }

    // READ ALL by project
    public List<DocumentDetails> getDocumentsByProject(Integer projectId) {
        return documentRepo.findByProject_ProjectId(projectId);
    }

    // READ ONE
    public DocumentDetails getDocumentById(Integer id) {
        return documentRepo.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Document not found with id: " + id));
    }

    // UPDATE
    public DocumentDetails updateDocument(Integer id, DocumentDetails updated) {
        DocumentDetails existing = getDocumentById(id);
        existing.setDocumentTitle(updated.getDocumentTitle());
        existing.setWordCount(updated.getWordCount());
        return documentRepo.save(existing);
    }

    // DELETE
    public void deleteDocument(Integer id) {
        getDocumentById(id);
        documentRepo.deleteById(id);
    }
}
