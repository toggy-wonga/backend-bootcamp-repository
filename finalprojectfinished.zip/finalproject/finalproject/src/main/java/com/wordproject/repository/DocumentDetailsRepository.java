package com.wordproject.repository;

import com.wordproject.entity.DocumentDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface DocumentDetailsRepository extends JpaRepository<DocumentDetails, Integer> {
    List<DocumentDetails> findByProject_ProjectId(Integer projectId);
}
