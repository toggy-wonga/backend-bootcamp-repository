package com.wordproject.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;

/**
 * A creative writing project owned by a User.
 *
 * Relationships:
 *   Many-to-one  -> User               (FK: userauthor_id)
 *   One-to-many  -> DocumentDetails
 *   Many-to-many -> ProjectTag (join table)
 */
@Entity
@Table(name = "project_details")
public class ProjectDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "project_id")
    private Integer projectId;

    @Column(name = "project_title")
    private String projectTitle;

    @Column(name = "project_description", columnDefinition = "TINYTEXT")
    private String projectDescription;

    // FK -> user.user_id  (maps to userauthor_id column in DB)
    @ManyToOne
    @JoinColumn(name = "userauthor_id", nullable = false)
    private User user;

    // One project -> many documents
    @OneToMany(mappedBy = "project", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonIgnore
    private List<DocumentDetails> documents = new ArrayList<>();

    // Many-to-many with tags via project_tag join table
    @ManyToMany
    @JoinTable(
        name = "project_tag",
        joinColumns = @JoinColumn(name = "projectid"),
        inverseJoinColumns = @JoinColumn(name = "tagid")
    )
    private List<ProjectTag> tags = new ArrayList<>();

    // ---- Constructors ----

    public ProjectDetails() {}

    public ProjectDetails(String projectTitle, String projectDescription, User user) {
        this.projectTitle = projectTitle;
        this.projectDescription = projectDescription;
        this.user = user;
    }

    // ---- Getters & Setters ----

    public Integer getProjectId() { return projectId; }
    public void setProjectId(Integer projectId) { this.projectId = projectId; }

    public String getProjectTitle() { return projectTitle; }
    public void setProjectTitle(String projectTitle) { this.projectTitle = projectTitle; }

    public String getProjectDescription() { return projectDescription; }
    public void setProjectDescription(String projectDescription) { this.projectDescription = projectDescription; }

    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }

    public List<DocumentDetails> getDocuments() { return documents; }
    public void setDocuments(List<DocumentDetails> documents) { this.documents = documents; }

    public List<ProjectTag> getTags() { return tags; }
    public void setTags(List<ProjectTag> tags) { this.tags = tags; }

    @Override
    public String toString() {
        return "ProjectDetails{projectId=" + projectId + ", projectTitle='" + projectTitle + "'}";
    }
}
