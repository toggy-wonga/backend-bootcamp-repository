package com.wordproject.controller;

import com.wordproject.entity.ProjectDetails;
import com.wordproject.entity.ProjectTag;
import com.wordproject.service.ProjectDetailsService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/projects")
@Tag(name = "Projects", description = "Manage creative writing projects — all 4 CRUD + many-to-many tag operations")
public class ProjectDetailsController {

    private final ProjectDetailsService projectService;

    @Autowired
    public ProjectDetailsController(ProjectDetailsService projectService) {
        this.projectService = projectService;
    }

    // POST /projects?userId={userId}
    @PostMapping
    @Operation(summary = "Create a project for a user")
    public ResponseEntity<ProjectDetails> createProject(
            @RequestParam Integer userId,
            @RequestBody ProjectDetails project) {
        return ResponseEntity.status(HttpStatus.CREATED)
            .body(projectService.createProject(userId, project));
    }

    // GET /projects
    @GetMapping
    @Operation(summary = "Get all projects")
    public ResponseEntity<List<ProjectDetails>> getAllProjects() {
        return ResponseEntity.ok(projectService.getAllProjects());
    }

    // GET /projects/user/{userId}
    @GetMapping("/user/{userId}")
    @Operation(summary = "Get all projects for a user")
    public ResponseEntity<List<ProjectDetails>> getProjectsByUser(@PathVariable Integer userId) {
        return ResponseEntity.ok(projectService.getProjectsByUser(userId));
    }

    // GET /projects/{id}
    @GetMapping("/{id}")
    @Operation(summary = "Get a project by ID")
    public ResponseEntity<ProjectDetails> getProjectById(@PathVariable Integer id) {
        return ResponseEntity.ok(projectService.getProjectById(id));
    }

    // PUT /projects/{id}
    @PutMapping("/{id}")
    @Operation(summary = "Update a project")
    public ResponseEntity<ProjectDetails> updateProject(
            @PathVariable Integer id,
            @RequestBody ProjectDetails project) {
        return ResponseEntity.ok(projectService.updateProject(id, project));
    }

    // DELETE /projects/{id}
    @DeleteMapping("/{id}")
    @Operation(summary = "Delete a project")
    public ResponseEntity<Void> deleteProject(@PathVariable Integer id) {
        projectService.deleteProject(id);
        return ResponseEntity.noContent().build();
    }

    // ---- Many-to-Many Tag Endpoints ----

    // GET /projects/{id}/tags
    @GetMapping("/{id}/tags")
    @Operation(summary = "Get all tags on a project (READ many-to-many)")
    public ResponseEntity<List<ProjectTag>> getTagsForProject(@PathVariable Integer id) {
        return ResponseEntity.ok(projectService.getTagsForProject(id));
    }

    // POST /projects/{id}/tags/{tagId}
    @PostMapping("/{id}/tags/{tagId}")
    @Operation(summary = "Add a tag to a project (CREATE many-to-many)")
    public ResponseEntity<ProjectDetails> addTag(
            @PathVariable Integer id,
            @PathVariable Integer tagId) {
        return ResponseEntity.ok(projectService.addTagToProject(id, tagId));
    }

    // DELETE /projects/{id}/tags/{tagId}
    @DeleteMapping("/{id}/tags/{tagId}")
    @Operation(summary = "Remove a tag from a project (DELETE many-to-many)")
    public ResponseEntity<ProjectDetails> removeTag(
            @PathVariable Integer id,
            @PathVariable Integer tagId) {
        return ResponseEntity.ok(projectService.removeTagFromProject(id, tagId));
    }
}
