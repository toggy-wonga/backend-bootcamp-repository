package com.wordproject.controller;

import com.wordproject.entity.DocumentWords;
import com.wordproject.service.DocumentWordsService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/document-words")
@Tag(name = "Document Words", description = "Word frequency entries — all 4 CRUD on the many-to-many relationship")
public class DocumentWordsController {

    private final DocumentWordsService documentWordsService;

    @Autowired
    public DocumentWordsController(DocumentWordsService documentWordsService) {
        this.documentWordsService = documentWordsService;
    }

    // POST /document-words?documentId={id}&wordId={id}&frequency={n}
    @PostMapping
    @Operation(summary = "Record a word in a document with frequency (CREATE many-to-many)")
    public ResponseEntity<DocumentWords> addWordToDocument(
            @RequestParam Integer documentId,
            @RequestParam Integer wordId,
            @RequestParam Integer frequency) {
        return ResponseEntity.status(HttpStatus.CREATED)
            .body(documentWordsService.addWordToDocument(documentId, wordId, frequency));
    }

    // GET /document-words
    @GetMapping
    @Operation(summary = "Get all document-word entries")
    public ResponseEntity<List<DocumentWords>> getAllDocumentWords() {
        return ResponseEntity.ok(documentWordsService.getAllDocumentWords());
    }

    // GET /document-words/document/{documentId}
    @GetMapping("/document/{documentId}")
    @Operation(summary = "Get all word entries for a document (READ many-to-many)")
    public ResponseEntity<List<DocumentWords>> getWordsForDocument(@PathVariable Integer documentId) {
        return ResponseEntity.ok(documentWordsService.getWordsForDocument(documentId));
    }

    // GET /document-words/{id}
    @GetMapping("/{id}")
    @Operation(summary = "Get a single document-word entry by ID")
    public ResponseEntity<DocumentWords> getById(@PathVariable Integer id) {
        return ResponseEntity.ok(documentWordsService.getDocumentWordById(id));
    }

    // PUT /document-words/{id}  body: { "frequency": 5 }
    @PutMapping("/{id}")
    @Operation(summary = "Update word frequency in a document (UPDATE many-to-many)")
    public ResponseEntity<DocumentWords> updateFrequency(
            @PathVariable Integer id,
            @RequestBody Map<String, Integer> body) {
        Integer frequency = body.get("frequency");
        return ResponseEntity.ok(documentWordsService.updateFrequency(id, frequency));
    }

    // DELETE /document-words/{id}
    @DeleteMapping("/{id}")
    @Operation(summary = "Remove a word entry from a document (DELETE many-to-many)")
    public ResponseEntity<Void> deleteDocumentWord(@PathVariable Integer id) {
        documentWordsService.deleteDocumentWord(id);
        return ResponseEntity.noContent().build();
    }
}
