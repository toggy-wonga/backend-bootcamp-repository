package com.wordproject.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;

/**
 * Join entity between DocumentDetails and Words.
 * Tracks how many times a word appears in a specific document (frequency).
 *
 * This is your many-to-many relationship with extra data on the join.
 */
@Entity
@Table(name = "document_words")
public class DocumentWords {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "document_words_id")
    private Integer documentWordsId;

    // FK -> document_details
    @ManyToOne
    @JoinColumn(name = "document_id")
    @JsonIgnore
    private DocumentDetails document;

    // FK -> words
    @ManyToOne
    @JoinColumn(name = "wordstuff_id", referencedColumnName = "word_id")
    private Words word;

    // How many times this word appears in this document
    @Column(name = "frequency")
    private Integer frequency;

    // ---- Constructors ----

    public DocumentWords() {}

    public DocumentWords(DocumentDetails document, Words word, Integer frequency) {
        this.document = document;
        this.word = word;
        this.frequency = frequency;
    }

    // ---- Getters & Setters ----

    public Integer getDocumentWordsId() { return documentWordsId; }
    public void setDocumentWordsId(Integer documentWordsId) { this.documentWordsId = documentWordsId; }

    public DocumentDetails getDocument() { return document; }
    public void setDocument(DocumentDetails document) { this.document = document; }

    public Words getWord() { return word; }
    public void setWord(Words word) { this.word = word; }

    public Integer getFrequency() { return frequency; }
    public void setFrequency(Integer frequency) { this.frequency = frequency; }

    @Override
    public String toString() {
        return "DocumentWords{id=" + documentWordsId + ", frequency=" + frequency + "}";
    }
}
