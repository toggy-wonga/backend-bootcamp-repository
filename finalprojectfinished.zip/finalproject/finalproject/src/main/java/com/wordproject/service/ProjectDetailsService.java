package com.wordproject.service;
import org.springframework.transaction.annotation.Transactional;

import com.wordproject.entity.ProjectDetails;
import com.wordproject.entity.ProjectTag;
import com.wordproject.entity.User;
import com.wordproject.errorhandling.ResourceNotFoundException;
import com.wordproject.repository.ProjectDetailsRepository;
import com.wordproject.repository.ProjectTagRepository;
import com.wordproject.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

/**
 * Service for ProjectDetails — all 4 CRUD operations.
 * Also handles the many-to-many tag relationship (Create + Delete on the join).
 */
@Transactional
@Service
public class ProjectDetailsService {

    private final ProjectDetailsRepository projectRepo;
    private final UserRepository userRepo;
    private final ProjectTagRepository tagRepo;

    @Autowired
    public ProjectDetailsService(ProjectDetailsRepository projectRepo,
                                  UserRepository userRepo,
                                  ProjectTagRepository tagRepo) {
        this.projectRepo = projectRepo;
        this.userRepo = userRepo;
        this.tagRepo = tagRepo;
    }

    // CREATE
    public ProjectDetails createProject(Integer userId, ProjectDetails project) {
        User user = userRepo.findById(userId)
            .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + userId));
        project.setProjectId(null);
        project.setUser(user);
        return projectRepo.save(project);
    }

    // READ ALL
    public List<ProjectDetails> getAllProjects() {
        return projectRepo.findAll();
    }

    // READ ALL by user
    public List<ProjectDetails> getProjectsByUser(Integer userId) {
        return projectRepo.findByUser_UserId(userId);
    }

    // READ ONE
    public ProjectDetails getProjectById(Integer id) {
        return projectRepo.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Project not found with id: " + id));
    }

    // UPDATE
    public ProjectDetails updateProject(Integer id, ProjectDetails updated) {
        ProjectDetails existing = getProjectById(id);
        existing.setProjectTitle(updated.getProjectTitle());
        existing.setProjectDescription(updated.getProjectDescription());
        return projectRepo.save(existing);
    }

    // DELETE
    public void deleteProject(Integer id) {
        getProjectById(id);
        projectRepo.deleteById(id);
    }

    // --- Many-to-Many: Tag operations ---

    // Add a tag to a project (CREATE on the relationship)
    public ProjectDetails addTagToProject(Integer projectId, Integer tagId) {
        ProjectDetails project = getProjectById(projectId);
        ProjectTag tag = tagRepo.findById(tagId)
            .orElseThrow(() -> new ResourceNotFoundException("Tag not found with id: " + tagId));
        if (!project.getTags().contains(tag)) {
            project.getTags().add(tag);
        }
        return projectRepo.save(project);
    }

    // Remove a tag from a project (DELETE on the relationship)
    public ProjectDetails removeTagFromProject(Integer projectId, Integer tagId) {
        ProjectDetails project = getProjectById(projectId);
        ProjectTag tag = tagRepo.findById(tagId)
            .orElseThrow(() -> new ResourceNotFoundException("Tag not found with id: " + tagId));
        project.getTags().remove(tag);
        return projectRepo.save(project);
    }

    // Read tags on a project (READ on the relationship)
    public List<ProjectTag> getTagsForProject(Integer projectId) {
        return getProjectById(projectId).getTags();
    }
}
