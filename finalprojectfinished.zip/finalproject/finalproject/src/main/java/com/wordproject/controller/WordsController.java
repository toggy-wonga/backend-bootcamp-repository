package com.wordproject.controller;

import com.wordproject.entity.Words;
import com.wordproject.service.WordsService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/words")
@Tag(name = "Words", description = "Manage the word catalog — Create, Read, Delete")
public class WordsController {

    private final WordsService wordsService;

    @Autowired
    public WordsController(WordsService wordsService) {
        this.wordsService = wordsService;
    }

    @PostMapping
    @Operation(summary = "Add a word to the catalog")
    public ResponseEntity<Words> createWord(@RequestBody Words word) {
        return ResponseEntity.status(HttpStatus.CREATED).body(wordsService.createWord(word));
    }

    @GetMapping
    @Operation(summary = "Get all words")
    public ResponseEntity<List<Words>> getAllWords() {
        return ResponseEntity.ok(wordsService.getAllWords());
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get a word by ID")
    public ResponseEntity<Words> getWordById(@PathVariable Integer id) {
        return ResponseEntity.ok(wordsService.getWordById(id));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete a word")
    public ResponseEntity<Void> deleteWord(@PathVariable Integer id) {
        wordsService.deleteWord(id);
        return ResponseEntity.noContent().build();
    }
}
