package com.wordproject.entity;

import jakarta.persistence.*;

/**
 * A tag that can be applied to many projects.
 * Stored in the 'tag' table.
 * The join to projects is managed by the 'project_tag' join table via ProjectDetails.
 */
@Entity
@Table(name = "tag")
public class ProjectTag {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "tagid")
    private Integer tagId;

    @Column(name = "tag_label")
    private String tagLabel;

    // ---- Constructors ----

    public ProjectTag() {}

    public ProjectTag(String tagLabel) {
        this.tagLabel = tagLabel;
    }

    // ---- Getters & Setters ----

    public Integer getTagId() { return tagId; }
    public void setTagId(Integer tagId) { this.tagId = tagId; }

    public String getTagLabel() { return tagLabel; }
    public void setTagLabel(String tagLabel) { this.tagLabel = tagLabel; }

    @Override
    public String toString() {
        return "ProjectTag{tagId=" + tagId + ", tagLabel='" + tagLabel + "'}";
    }
}
