package com.wordproject.repository;

import com.wordproject.entity.ProjectDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ProjectDetailsRepository extends JpaRepository<ProjectDetails, Integer> {
    List<ProjectDetails> findByUser_UserId(Integer userId);
}
