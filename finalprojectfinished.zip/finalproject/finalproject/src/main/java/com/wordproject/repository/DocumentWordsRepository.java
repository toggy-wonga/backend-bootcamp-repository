package com.wordproject.repository;

import com.wordproject.entity.DocumentWords;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface DocumentWordsRepository extends JpaRepository<DocumentWords, Integer> {
    List<DocumentWords> findByDocument_DocumentId(Integer documentId);
}
