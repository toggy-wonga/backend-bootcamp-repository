package com.wordproject.controller;

import com.wordproject.entity.DocumentDetails;
import com.wordproject.service.DocumentDetailsService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/documents")
@Tag(name = "Documents", description = "Manage documents within projects — all 4 CRUD operations")
public class DocumentDetailsController {

    private final DocumentDetailsService documentService;

    @Autowired
    public DocumentDetailsController(DocumentDetailsService documentService) {
        this.documentService = documentService;
    }

    // POST /documents?projectId={projectId}
    @PostMapping
    @Operation(summary = "Create a document under a project")
    public ResponseEntity<DocumentDetails> createDocument(
            @RequestParam Integer projectId,
            @RequestBody DocumentDetails document) {
        return ResponseEntity.status(HttpStatus.CREATED)
            .body(documentService.createDocument(projectId, document));
    }

    // GET /documents
    @GetMapping
    @Operation(summary = "Get all documents")
    public ResponseEntity<List<DocumentDetails>> getAllDocuments() {
        return ResponseEntity.ok(documentService.getAllDocuments());
    }

    // GET /documents/project/{projectId}
    @GetMapping("/project/{projectId}")
    @Operation(summary = "Get all documents for a project")
    public ResponseEntity<List<DocumentDetails>> getByProject(@PathVariable Integer projectId) {
        return ResponseEntity.ok(documentService.getDocumentsByProject(projectId));
    }

    // GET /documents/{id}
    @GetMapping("/{id}")
    @Operation(summary = "Get a document by ID")
    public ResponseEntity<DocumentDetails> getDocumentById(@PathVariable Integer id) {
        return ResponseEntity.ok(documentService.getDocumentById(id));
    }

    // PUT /documents/{id}
    @PutMapping("/{id}")
    @Operation(summary = "Update a document")
    public ResponseEntity<DocumentDetails> updateDocument(
            @PathVariable Integer id,
            @RequestBody DocumentDetails document) {
        return ResponseEntity.ok(documentService.updateDocument(id, document));
    }

    // DELETE /documents/{id}
    @DeleteMapping("/{id}")
    @Operation(summary = "Delete a document")
    public ResponseEntity<Void> deleteDocument(@PathVariable Integer id) {
        documentService.deleteDocument(id);
        return ResponseEntity.noContent().build();
    }
}
