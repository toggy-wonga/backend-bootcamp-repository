package com.wordproject.service;
import org.springframework.transaction.annotation.Transactional;

import com.wordproject.entity.DocumentDetails;
import com.wordproject.entity.DocumentWords;
import com.wordproject.entity.Words;
import com.wordproject.errorhandling.ResourceNotFoundException;
import com.wordproject.repository.DocumentDetailsRepository;
import com.wordproject.repository.DocumentWordsRepository;
import com.wordproject.repository.WordsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

/**
 * Service for DocumentWords — Create, Read, Update, Delete.
 * This is the many-to-many join entity between DocumentDetails and Words.
 */
@Transactional
@Service
public class DocumentWordsService {

    private final DocumentWordsRepository docWordsRepo;
    private final DocumentDetailsRepository documentRepo;
    private final WordsRepository wordsRepo;

    @Autowired
    public DocumentWordsService(DocumentWordsRepository docWordsRepo,
                                  DocumentDetailsRepository documentRepo,
                                  WordsRepository wordsRepo) {
        this.docWordsRepo = docWordsRepo;
        this.documentRepo = documentRepo;
        this.wordsRepo = wordsRepo;
    }

    // CREATE — record that a word appears in a document with a given frequency
    public DocumentWords addWordToDocument(Integer documentId, Integer wordId, Integer frequency) {
        DocumentDetails document = documentRepo.findById(documentId)
            .orElseThrow(() -> new ResourceNotFoundException("Document not found with id: " + documentId));
        Words word = wordsRepo.findById(wordId)
            .orElseThrow(() -> new ResourceNotFoundException("Word not found with id: " + wordId));

        DocumentWords dw = new DocumentWords(document, word, frequency);
        return docWordsRepo.save(dw);
    }

    // READ ALL entries for a document
    public List<DocumentWords> getWordsForDocument(Integer documentId) {
        return docWordsRepo.findByDocument_DocumentId(documentId);
    }

    // READ ALL
    public List<DocumentWords> getAllDocumentWords() {
        return docWordsRepo.findAll();
    }

    // READ ONE
    public DocumentWords getDocumentWordById(Integer id) {
        return docWordsRepo.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("DocumentWords entry not found with id: " + id));
    }

    // UPDATE — change the frequency count
    public DocumentWords updateFrequency(Integer id, Integer newFrequency) {
        DocumentWords existing = getDocumentWordById(id);
        existing.setFrequency(newFrequency);
        return docWordsRepo.save(existing);
    }

    // DELETE
    public void deleteDocumentWord(Integer id) {
        getDocumentWordById(id);
        docWordsRepo.deleteById(id);
    }
}
