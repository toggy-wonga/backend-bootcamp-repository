package com.wordproject.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;

/**
 * A unique word in the catalog.
 * Note: word_count here is VARCHAR in your schema -- treated as the word value string.
 */
@Entity
@Table(name = "words")
public class Words {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "word_id")
    private Integer wordId;

    // In your MWB schema this column is called word_count but is VARCHAR -- it holds the word string
    @Column(name = "word_count")
    private String wordValue;

    @OneToMany(mappedBy = "word", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonIgnore
    private List<DocumentWords> documentWords = new ArrayList<>();

    // ---- Constructors ----

    public Words() {}

    public Words(String wordValue) {
        this.wordValue = wordValue;
    }

    // ---- Getters & Setters ----

    public Integer getWordId() { return wordId; }
    public void setWordId(Integer wordId) { this.wordId = wordId; }

    public String getWordValue() { return wordValue; }
    public void setWordValue(String wordValue) { this.wordValue = wordValue; }

    public List<DocumentWords> getDocumentWords() { return documentWords; }
    public void setDocumentWords(List<DocumentWords> documentWords) { this.documentWords = documentWords; }

    @Override
    public String toString() {
        return "Words{wordId=" + wordId + ", wordValue='" + wordValue + "'}";
    }
}
