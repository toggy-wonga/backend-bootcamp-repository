package com.wordproject.service;
import org.springframework.transaction.annotation.Transactional;

import com.wordproject.entity.Words;
import com.wordproject.errorhandling.ResourceNotFoundException;
import com.wordproject.repository.WordsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

/**
 * Service for Words — Create and Read.
 */
@Transactional
@Service
public class WordsService {

    private final WordsRepository wordsRepository;

    @Autowired
    public WordsService(WordsRepository wordsRepository) {
        this.wordsRepository = wordsRepository;
    }

    // CREATE
    public Words createWord(Words word) {
        word.setWordId(null);
        return wordsRepository.save(word);
    }

    // READ ALL
    public List<Words> getAllWords() {
        return wordsRepository.findAll();
    }

    // READ ONE
    public Words getWordById(Integer id) {
        return wordsRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Word not found with id: " + id));
    }

    // DELETE
    public void deleteWord(Integer id) {
        getWordById(id);
        wordsRepository.deleteById(id);
    }
}
