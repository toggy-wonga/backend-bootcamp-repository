package com.wordproject.service;
import org.springframework.transaction.annotation.Transactional;

import com.wordproject.entity.User;
import com.wordproject.errorhandling.ResourceNotFoundException;
import com.wordproject.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

/**
 * Service for User — all 4 CRUD operations.
 */
@Transactional
@Service
public class UserService {

    private final UserRepository userRepository;

    @Autowired
    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    // CREATE
    public User createUser(User user) {
        user.setUserId(null);
        return userRepository.save(user);
    }

    // READ ALL
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    // READ ONE
    public User getUserById(Integer id) {
        return userRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + id));
    }

    // UPDATE
    public User updateUser(Integer id, User updatedUser) {
        User existing = getUserById(id);
        existing.setUserName(updatedUser.getUserName());
        existing.setUserEmail(updatedUser.getUserEmail());
        return userRepository.save(existing);
    }

    // DELETE
    public void deleteUser(Integer id) {
        getUserById(id); // will throw if not found
        userRepository.deleteById(id);
    }
}
