package com.wordproject.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;

/**
 * An individual document (chapter, story, poem, etc.) belonging to a Project.
 *
 * Relationships:
 *   Many-to-one  -> ProjectDetails   (FK: project_id / project_userauthor_id)
 *   One-to-many  -> DocumentWords    (word frequency tracking)
 */
@Entity
@Table(name = "document_details")
public class DocumentDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "document_id")
    private Integer documentId;

    @Column(name = "project_title")
    private String documentTitle;   // re-using project_title column for the document's own title

    @Column(name = "word_count")
    private Integer wordCount;

    // FK -> project_details
    @ManyToOne
    @JoinColumn(name = "project_id")
    @JsonIgnore
    private ProjectDetails project;

    // One document -> many word-frequency entries
    @OneToMany(mappedBy = "document", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonIgnore
    private List<DocumentWords> documentWords = new ArrayList<>();

    // ---- Constructors ----

    public DocumentDetails() {}

    public DocumentDetails(String documentTitle, Integer wordCount, ProjectDetails project) {
        this.documentTitle = documentTitle;
        this.wordCount = wordCount;
        this.project = project;
    }

    // ---- Getters & Setters ----

    public Integer getDocumentId() { return documentId; }
    public void setDocumentId(Integer documentId) { this.documentId = documentId; }

    public String getDocumentTitle() { return documentTitle; }
    public void setDocumentTitle(String documentTitle) { this.documentTitle = documentTitle; }

    public Integer getWordCount() { return wordCount; }
    public void setWordCount(Integer wordCount) { this.wordCount = wordCount; }

    public ProjectDetails getProject() { return project; }
    public void setProject(ProjectDetails project) { this.project = project; }

    public List<DocumentWords> getDocumentWords() { return documentWords; }
    public void setDocumentWords(List<DocumentWords> documentWords) { this.documentWords = documentWords; }

    @Override
    public String toString() {
        return "DocumentDetails{documentId=" + documentId + ", documentTitle='" + documentTitle + "', wordCount=" + wordCount + "}";
    }
}
