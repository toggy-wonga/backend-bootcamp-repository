package com.wordproject.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Represents a registered user / author in the system.
 * One-to-many relationship with ProjectDetails.
 */
@Entity
@Table(name = "user")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "user_id")
    private Integer userId;

    @Column(name = "user_name")
    private String userName;

    @Column(name = "user_email")
    private String userEmail;

    // One user -> many projects
    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonIgnore
    private List<ProjectDetails> projects = new ArrayList<>();

    // ---- Constructors ----

    public User() {}

    public User(String userName, String userEmail) {
        this.userName = userName;
        this.userEmail = userEmail;
    }

    // ---- Getters & Setters ----

    public Integer getUserId() { return userId; }
    public void setUserId(Integer userId) { this.userId = userId; }

    public String getUserName() { return userName; }
    public void setUserName(String userName) { this.userName = userName; }

    public String getUserEmail() { return userEmail; }
    public void setUserEmail(String userEmail) { this.userEmail = userEmail; }

    public List<ProjectDetails> getProjects() { return projects; }
    public void setProjects(List<ProjectDetails> projects) { this.projects = projects; }

    @Override
    public String toString() {
        return "User{userId=" + userId + ", userName='" + userName + "', userEmail='" + userEmail + "'}";
    }
}
