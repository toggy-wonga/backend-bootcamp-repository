package com.wordproject.service;
import org.springframework.transaction.annotation.Transactional;

import com.wordproject.entity.ProjectTag;
import com.wordproject.errorhandling.ResourceNotFoundException;
import com.wordproject.repository.ProjectTagRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

/**
 * Service for ProjectTag — Create, Read, Delete.
 */
@Transactional
@Service
public class ProjectTagService {

    private final ProjectTagRepository tagRepository;

    @Autowired
    public ProjectTagService(ProjectTagRepository tagRepository) {
        this.tagRepository = tagRepository;
    }

    // CREATE
    public ProjectTag createTag(ProjectTag tag) {
        tag.setTagId(null);
        return tagRepository.save(tag);
    }

    // READ ALL
    public List<ProjectTag> getAllTags() {
        return tagRepository.findAll();
    }

    // READ ONE
    public ProjectTag getTagById(Integer id) {
        return tagRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Tag not found with id: " + id));
    }

    // DELETE
    public void deleteTag(Integer id) {
        getTagById(id);
        tagRepository.deleteById(id);
    }
}
