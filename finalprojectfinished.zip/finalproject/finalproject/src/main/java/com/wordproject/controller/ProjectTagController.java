package com.wordproject.controller;

import com.wordproject.entity.ProjectTag;
import com.wordproject.service.ProjectTagService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/tags")
@Tag(name = "Tags", description = "Manage project tags")
public class ProjectTagController {

    private final ProjectTagService tagService;

    @Autowired
    public ProjectTagController(ProjectTagService tagService) {
        this.tagService = tagService;
    }

    @PostMapping
    @Operation(summary = "Create a tag")
    public ResponseEntity<ProjectTag> createTag(@RequestBody ProjectTag tag) {
        return ResponseEntity.status(HttpStatus.CREATED).body(tagService.createTag(tag));
    }

    @GetMapping
    @Operation(summary = "Get all tags")
    public ResponseEntity<List<ProjectTag>> getAllTags() {
        return ResponseEntity.ok(tagService.getAllTags());
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get a tag by ID")
    public ResponseEntity<ProjectTag> getTagById(@PathVariable Integer id) {
        return ResponseEntity.ok(tagService.getTagById(id));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete a tag")
    public ResponseEntity<Void> deleteTag(@PathVariable Integer id) {
        tagService.deleteTag(id);
        return ResponseEntity.noContent().build();
    }
}
